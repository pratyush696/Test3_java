module com.example.test3_java {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;
    requires java.sql;

    opens com.example.test3_java to javafx.fxml;
    exports com.example.test3_java;
}