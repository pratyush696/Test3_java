package com.example.test3_java;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Label welcomeText;

    @FXML
    private TableView<Pizza> gametable;
    @FXML
    private TableColumn<Pizza, Integer> id;
    @FXML
    private TableColumn<Pizza, String> name;
    @FXML
    private TableColumn<Pizza, Integer> mobile;
    @FXML
    private TableColumn<Pizza, String> size;
    @FXML
    private TableColumn<Pizza, Integer> toppings;
    @FXML
    private TableColumn<Pizza, Double> bill;

    @FXML
    private TextField uid;
    @FXML
    private TextField uname;
    @FXML
    private TextField umobile;
    @FXML
    private TextField usize;
    @FXML
    private TextField utoppings;

    ObservableList<Pizza> list = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        name.setCellValueFactory(new PropertyValueFactory<>("name"));
        mobile.setCellValueFactory(new PropertyValueFactory<>("mobile"));
        size.setCellValueFactory(new PropertyValueFactory<>("size"));
        toppings.setCellValueFactory(new PropertyValueFactory<>("toppings"));
        bill.setCellValueFactory(new PropertyValueFactory<>("bill"));

        gametable.setItems(list);
        populateTable();
    }

    @FXML
    protected void onHelloButtonClick(ActionEvent event) {
        welcomeText.setText("Hello!");
    }

    public void populateTable() {
        list.clear();
        String jdbcUrl = "jdbc:mysql://localhost:3306/pizza";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM pizza";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int mobile = resultSet.getInt("mobile");
                String size = resultSet.getString("size");
                int toppings = resultSet.getInt("toppings");
                double bill = resultSet.getDouble("bill");

                list.add(new Pizza(id, name, mobile, size, toppings, bill));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertData(ActionEvent event) {
        String name = uname.getText();
        int mobile = Integer.parseInt(umobile.getText());
        String size = usize.getText();
        int toppings = Integer.parseInt(utoppings.getText());
        double bill = calculateTotalBill(size, toppings);

        String jdbcUrl = "jdbc:mysql://localhost:3306/pizza";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "INSERT INTO pizza (name, mobile, size, toppings, bill) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, mobile);
            preparedStatement.setString(3, size);
            preparedStatement.setInt(4, toppings);
            preparedStatement.setDouble(5, bill);

            preparedStatement.executeUpdate();
            populateTable(); // Refresh table data
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateData(ActionEvent event) {
        int id = Integer.parseInt(uid.getText());
        String name = uname.getText();
        int mobile = Integer.parseInt(umobile.getText());
        String size = usize.getText();
        int toppings = Integer.parseInt(utoppings.getText());
        double bill = calculateTotalBill(size, toppings);

        String jdbcUrl = "jdbc:mysql://localhost:3306/pizza";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE pizza SET name=?, mobile=?, size=?, toppings=?, bill=? WHERE id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, mobile);
            preparedStatement.setString(3, size);
            preparedStatement.setInt(4, toppings);
            preparedStatement.setDouble(5, bill);
            preparedStatement.setInt(6, id);

            preparedStatement.executeUpdate();
            populateTable(); // Refresh table data
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteData(ActionEvent event) {
        int id = Integer.parseInt(uid.getText());

        String jdbcUrl = "jdbc:mysql://localhost:3306/pizza";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM pizza WHERE id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);

            preparedStatement.executeUpdate();
            populateTable(); // Refresh table data
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public double calculateTotalBill(String size, int toppings) {
        double baseCost = 0.0;
        switch (size) {
            case "XL":
                baseCost = 15.00;
                break;
            case "L":
                baseCost = 12.00;
                break;
            case "M":
                baseCost = 10.00;
                break;
            case "S":
                baseCost = 8.00;
                break;
            default:
                break;
        }
        double totalCost = baseCost + (toppings * 1.50);
        double hst = totalCost * 0.15;
        return totalCost + hst;
    }
}
