package com.example.test3_java;

public class Pizza {
    private int id;
    private String name;
    private int mobile;
    private String size;
    private int toppings;
    private double bill;

    public Pizza(int id, String name, int mobile, String size, int toppings, double bill) {
        this.id = id;
        this.name = name;
        this.mobile = mobile;
        this.size = size;
        this.toppings = toppings;
        this.bill = bill;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMobile() {
        return mobile;
    }

    public void setMobile(int mobile) {
        this.mobile = mobile;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public int getToppings() {
        return toppings;
    }

    public void setToppings(int toppings) {
        this.toppings = toppings;
    }

    public double getBill() {
        return bill;
    }

    public void setBill(double bill) {
        this.bill = bill;
    }
}