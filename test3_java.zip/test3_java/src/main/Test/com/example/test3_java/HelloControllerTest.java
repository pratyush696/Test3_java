package com.example.test3_java;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class HelloControllerTest {

    private HelloController controller; // Assuming calculateTotalBill method is in HelloController

    @BeforeEach
    void setUp() {
        controller = new HelloController();
    }

    @Test
    void testCalculateTotalBillXLWithToppings() {
        double totalBill = controller.calculateTotalBill("XL", 3);
        assertEquals(23.025, totalBill, 0.001); // Expected total: 15 (base) + 4.5 (toppings) = 19.5 * 1.15 = 23.025
    }

    @Test
    void testCalculateTotalBillLWithoutToppings() {
        double totalBill = controller.calculateTotalBill("L", 0);
        assertEquals(13.8, totalBill, 0.001); // Expected total: 12 (base) * 1.15 = 13.8
    }

    @Test
    void testCalculateTotalBillMWithManyToppings() {
        double totalBill = controller.calculateTotalBill("M", 5);
        assertEquals(19.725, totalBill, 0.001); // Expected total: 10 (base) + 7.5 (toppings) = 17.5 * 1.15 = 19.725
    }

    @Test
    void testCalculateTotalBillSWithFewToppings() {
        double totalBill = controller.calculateTotalBill("S", 1);
        assertEquals(10.345, totalBill, 0.001); // Expected total: 8 (base) + 1.5 (toppings) = 9.5 * 1.15 = 10.345
    }

    @Test
    void testCalculateTotalBillInvalidSize() {
        assertThrows(IllegalArgumentException.class, () -> {
            controller.calculateTotalBill("XXL", 2); // Invalid size should throw exception
        });
    }
}
